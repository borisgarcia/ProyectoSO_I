#!/bin/bash

bin/sfs $1 $2 -f -s


